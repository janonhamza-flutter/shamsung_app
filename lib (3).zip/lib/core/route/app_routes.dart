class AppRoutes {
  static const splash = "/";
  static const login = "/login";
  static const sendOtp = "/sendOtp";
  static const otp = "/otp";
  static const signup = "/signup";
  static const home = "/home";
  static const profile = '/profile';
}
