class AppValidator {
  static String? validateEmail(String value) {
    if (value.isEmpty) {
      return "Email is required";
    }

    if (!value.contains("@")) {
      return "Invalid email";
    }

    return null;
  }

  static String? validatePassword(String value) {
    if (value.isEmpty) {
      return "Password is required";
    }

    if (value.length < 8) {
      return "Password too short";
    }

    return null;
  }

  static String? validateName(String value) {
    if (value.isEmpty) {
      return "Name is required";
    }

    return null;
  }

  static String? validateMobile(String value) {
    if (value.isEmpty) {
      return "Mobile is required";
    }

    if (value.length < 10) {
      return "Enter valid mobile number";
    }

    return null;
  }
}
