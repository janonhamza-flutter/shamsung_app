import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../core/route/app_routes.dart';
import '../../../../core/widgets/app_snackbar.dart';
import '../../data/repositories/auth_repository.dart';

class SignupController extends GetxController {
  /// =========================
  /// TEXT CONTROLLERS
  /// =========================

  final fullNameController = TextEditingController();

  final mobileController = TextEditingController();

  final emailController = TextEditingController();

  final passwordController = TextEditingController();

  final formKey = GlobalKey<FormState>();

  /// =========================
  /// DIO SERVICE
  /// =========================

  final AuthRepository authRepository = AuthRepository();

  /// =========================
  /// PASSWORD VISIBILITY
  /// =========================

  RxBool obscureText = true.obs;

  void togglePasswordVisibility() {
    obscureText.value = !obscureText.value;
  }

  /// =========================
  /// SIGN UP
  /// =========================

  void signUp() async {
    if (!formKey.currentState!.validate()) {
      return;
    }

    try {
      final response = await authRepository.signUp(
        fullName: fullNameController.text,
        mobile: mobileController.text,
        email: emailController.text,
        password: passwordController.text,
      );

      print(response.data);

      AppSnackbar.success("Account Created Successfully");
    } catch (e) {
      print(e);

      Get.offAllNamed(AppRoutes.home);
      AppSnackbar.error("Signup Failed");
    }
  }

  /// =========================
  /// DISPOSE
  /// =========================

  @override
  void onClose() {
    fullNameController.dispose();

    mobileController.dispose();

    emailController.dispose();

    passwordController.dispose();

    super.onClose();
  }
}
