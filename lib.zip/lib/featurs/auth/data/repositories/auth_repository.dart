import '../../../../core/services/dio_service.dart';

class AuthRepository {
  final DioService dioService = DioService();

  /// LOGIN

  Future login({required String email, required String password}) async {
    return await dioService.postData(
      endpoint: "login",

      data: {"email": email, "password": password},
    );
  }

  /// SIGN UP

  Future signUp({
    required String fullName,

    required String mobile,

    required String email,

    required String password,
  }) async {
    return await dioService.postData(
      endpoint: "register",

      data: {
        "full_name": fullName,

        "mobile": mobile,

        "email": email,

        "password": password,
      },
    );
  }
}
